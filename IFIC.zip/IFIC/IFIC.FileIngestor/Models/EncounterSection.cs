﻿/************************************************************************************
* FILE          : EncounterSection.cs
* PROJECT       : IFIC-XML
* PROGRAMMER    : Your Name
* FIRST VERSION : 2025-08-02
* DESCRIPTION   : Represents encounter-specific data fields parsed from the flat file.
************************************************************************************/

using System.Collections.Generic;

namespace IFIC.FileIngestor.Models
{
    /********************************************************************************
    * CLASS NAME   : EncounterSection
    * DESCRIPTION  : Holds all flat file fields related to encounter information.
    *********************************************************************************/
    public class EncounterSection
    {
        /// <summary>
        /// Dictionary of encounter-related fields (key = flat file key, value = field value).
        /// </summary>
        public Dictionary<string, string> Fields { get; set; } = new Dictionary<string, string>();
    }
}
