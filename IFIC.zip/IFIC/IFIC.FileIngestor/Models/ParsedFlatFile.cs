﻿/************************************************************************************
* FILE          : ParsedFlatFile.cs
* PROJECT       : IFIC-XML
* PROGRAMMER    : Your Name
* FIRST VERSION : 2025-08-02
* DESCRIPTION   : Represents the parsed data from a Clarity flat file, including 
*                 Patient, Encounter, Assessment sections, and administrative data.
************************************************************************************/

using System.Collections.Generic;

namespace IFIC.FileIngestor.Models
{
    /********************************************************************************
    * CLASS NAME   : ParsedFlatFile
    * DESCRIPTION  : Represents the complete parsed structure of the input flat file.
    *********************************************************************************/
    public class ParsedFlatFile
    {
        /// <summary>
        /// Administrative information section (not used in FHIR submission).
        /// </summary>
        public AdminSection Admin { get; set; } = new AdminSection();

        /// <summary>
        /// Patient information section.
        /// </summary>
        public PatientSection Patient { get; set; } = new PatientSection();

        /// <summary>
        /// Encounter information section.
        /// </summary>
        public EncounterSection Encounter { get; set; } = new EncounterSection();

        /// <summary>
        /// Assessment sections, grouped by section name (e.g., SECTION A, SECTION B).
        /// </summary>
        public Dictionary<string, Dictionary<string, string>> AssessmentSections { get; set; }
            = new Dictionary<string, Dictionary<string, string>>();
    }
}
