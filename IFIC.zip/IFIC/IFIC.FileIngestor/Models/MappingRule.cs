﻿/************************************************************************************
* FILE          : MappingRule.cs
* PROJECT       : IFIC-XML
* PROGRAMMER    : Your Name
* FIRST VERSION : 2025-08-01
* DESCRIPTION   : Represents a single mapping rule between a Clarity flat file field
*                 and its corresponding FHIR XML element path, including metadata
*                 such as mandatory flag, validation rules, and allowed values.
************************************************************************************/

using System.Collections.Generic;

namespace IFIC.FileIngestor.Models
{
    /********************************************************************************
    * CLASS NAME   : MappingRule
    * DESCRIPTION  : Holds mapping details for transforming a flat file field into a 
    *                FHIR-compliant XML element. This includes:
    *                - Section and key from the flat file
    *                - FHIR XML path
    *                - Data type (e.g., string, decimal)
    *                - Mandatory flag
    *                - Validation rules
    *                - Allowed values (from CIHI value sets)
    *********************************************************************************/
    public class MappingRule
    {
        /// <summary>
        /// Flat file section name (e.g., PATIENT, ENCOUNTER, SECTION A).
        /// </summary>
        public string Section { get; set; }

        /// <summary>
        /// Key from the flat file (e.g., A5A, B2).
        /// </summary>
        public string FlatFileKey { get; set; }

        /// <summary>
        /// FHIR XML element path for mapping this value (e.g., Patient.identifier[0].value).
        /// </summary>
        public string FhirPath { get; set; }

        /// <summary>
        /// Data type for the field value (e.g., string, decimal, code).
        /// </summary>
        public string DataType { get; set; }

        /// <summary>
        /// Indicates if this field is mandatory as per CIHI IRRS mandatory element matrix.
        /// </summary>
        public bool IsMandatory { get; set; }

        /// <summary>
        /// Validation rule or constraint as per IRRS business rules (if applicable).
        /// </summary>
        public string ValidationRule { get; set; }

        /// <summary>
        /// List of allowed values (codes) if the field is constrained to a value set.
        /// </summary>
        public List<string> AllowedValues { get; set; } = new List<string>();
    }
}
