﻿/************************************************************************************
* FILE          : AdminSection.cs
* PROJECT       : IFIC-XML
* PROGRAMMER    : Your Name
* FIRST VERSION : 2025-08-02
* DESCRIPTION   : Represents administrative information from the flat file header.
************************************************************************************/

using System.Collections.Generic;

namespace IFIC.FileIngestor.Models
{
    /********************************************************************************
    * CLASS NAME   : AdminSection
    * DESCRIPTION  : Holds metadata and administrative fields (not mapped to FHIR).
    *********************************************************************************/
    public class AdminSection
    {
        /// <summary>
        /// Dictionary of administrative fields (key = field name, value = field value).
        /// </summary>
        public Dictionary<string, string> Fields { get; set; } = new Dictionary<string, string>();
    }
}
