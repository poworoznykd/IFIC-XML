﻿/************************************************************************************
* FILE          : FhirPipeline.cs
* PROJECT       : IFIC - IRRS/FHIR Intermediary Component
* PROGRAMMER    : Darryl Poworoznyk
* FIRST VERSION : 2025-08-01
* DESCRIPTION   :
*   Handles end-to-end process:
*     - Parse flat file
*     - Load mapping rules
*     - Build FHIR XML
*     - Submit to CIHI using OAuth2
************************************************************************************/

using System;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using IFIC.FileIngestor.Parsers;
using IFIC.FileIngestor.Mapping;
using Microsoft.Extensions.Configuration;
using IFIC.Auth;
using IFIC.FileIngestor.Builders;

namespace IFIC.FileIngestor.Pipeline
{
    /// <summary>
    /// Pipeline to transform flat files into FHIR XML and submit them to CIHI.
    /// </summary>
    public class FhirPipeline
    {
        private readonly string _mappingFilePath;
        private readonly IConfiguration _config;

        /// <summary>
        /// Initializes a new instance of FhirPipeline.
        /// </summary>
        /// <param name="mappingFilePath">Path to mapping Excel file.</param>
        /// <param name="config">Application configuration (OAuth2 and CIHI endpoint).</param>
        public FhirPipeline(string mappingFilePath, IConfiguration config)
        {
            _mappingFilePath = mappingFilePath ?? throw new ArgumentNullException(nameof(mappingFilePath));
            _config = config ?? throw new ArgumentNullException(nameof(config));
        }

        /// <summary>
        /// Processes a flat file, builds a FHIR XML bundle, and submits it to CIHI.
        /// </summary>
        /// <param name="inputFilePath">Path to the flat file.</param>
        /// <returns>Response from CIHI as a string.</returns>
        public async Task<string> ProcessAndSubmitFlatFileAsync(string inputFilePath)
        {
            if (!File.Exists(inputFilePath))
            {
                throw new FileNotFoundException("Flat file not found.", inputFilePath);
            }

            Console.WriteLine("Step 1: Parsing flat file...");
            var parser = new FlatFileParser();
            var parsedData = parser.ParseFile(inputFilePath);

            Console.WriteLine("Step 2: Loading mapping rules...");
            var loader = new ExcelMappingLoader();
            var mappings = loader.LoadMappings(_mappingFilePath);

            Console.WriteLine("Step 3: Building FHIR XML bundle...");
            var builder = new FhirXmlBuilder(mappings);
            XElement bundleXml = builder.BuildBundle(parsedData);
            string xmlString = new XDocument(bundleXml).ToString();

            Console.WriteLine("Step 4: Requesting OAuth2 token...");
            string token = await OAuthHelper.GetAccessTokenAsync(
                _config["OAuth2:TokenUrl"],
                _config["OAuth2:ClientId"],
                _config["OAuth2:ClientSecret"]);

            Console.WriteLine("Step 5: Submitting bundle to CIHI...");
            using var client = new HttpClient();
            client.DefaultRequestHeaders.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

            var content = new StringContent(xmlString, Encoding.UTF8, "application/fhir+xml");
            var response = await client.PostAsync(_config["CihiApi:Endpoint"], content);

            Console.WriteLine($"Response Status: {response.StatusCode}");
            return await response.Content.ReadAsStringAsync();
        }
    }
}
