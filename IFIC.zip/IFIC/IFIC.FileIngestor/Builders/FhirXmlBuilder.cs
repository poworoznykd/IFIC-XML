﻿/************************************************************************************
* FILE          : FhirXmlBuilder.cs
* PROJECT       : IFIC-XML
* PROGRAMMER    : Your Name
* FIRST VERSION : 2025-08-02
* DESCRIPTION   : This class is responsible for building FHIR-compliant XML bundles
*                 from parsed flat file data and mapping rules. The output conforms
*                 to CIHI IRRS specifications for LTCF submissions.
************************************************************************************/

using System;
using System.Collections.Generic;
using System.Xml.Linq;
using IFIC.FileIngestor.Models;

namespace IFIC.FileIngestor.Builders
{
    /********************************************************************************
    * CLASS NAME   : FhirXmlBuilder
    * DESCRIPTION  : Builds FHIR-compliant XML Bundle containing Patient, Encounter,
    *                and QuestionnaireResponse resources using parsed flat file data
    *                and mapping definitions.
    *********************************************************************************/
    public class FhirXmlBuilder
    {
        private readonly List<MappingRule> _mappingRules;
        private readonly XNamespace _fhirNamespace = "http://hl7.org/fhir";

        /********************************************************************************
        * FUNCTION     : FhirXmlBuilder (Constructor)
        * DESCRIPTION  : Initializes the FhirXmlBuilder with the provided mapping rules.
        *
        * PARAMETERS   : List<MappingRule> mappingRules : Mapping rules for flat file keys
        *                                              to FHIR resource paths.
        *********************************************************************************/
        public FhirXmlBuilder(List<MappingRule> mappingRules)
        {
            _mappingRules = mappingRules ?? throw new ArgumentNullException(nameof(mappingRules));
        }

        /********************************************************************************
        * FUNCTION     : BuildBundle
        * DESCRIPTION  : Constructs an XML Bundle element containing Patient, Encounter,
        *                and QuestionnaireResponse resources populated using parsed flat
        *                file data and mapping rules.
        *
        * PARAMETERS   : ParsedFlatFile parsedFile : Parsed flat file object containing
        *                                            Patient, Encounter, and Assessment data.
        *
        * RETURNS      : XElement : Root Bundle XML element compliant with FHIR.
        *********************************************************************************/
        public XElement BuildBundle(ParsedFlatFile parsedFile)
        {
            if (parsedFile == null)
            {
                throw new ArgumentNullException(nameof(parsedFile));
            }

            var bundle = new XElement(_fhirNamespace + "Bundle",
                new XAttribute("xmlns", _fhirNamespace.NamespaceName),
                new XElement(_fhirNamespace + "id", new XAttribute("value", Guid.NewGuid().ToString())),
                new XElement(_fhirNamespace + "type", new XAttribute("value", "transaction"))
            );


            // Add Patient resource entry
            var patientElement = BuildPatientElement(parsedFile);
            bundle.Add(CreateEntry(patientElement));

            // Add Encounter resource entry
            var encounterElement = BuildEncounterElement(parsedFile);
            bundle.Add(CreateEntry(encounterElement));

            // Add QuestionnaireResponse resource entry
            var questionnaireElement = BuildQuestionnaireResponseElement(parsedFile);
            bundle.Add(CreateEntry(questionnaireElement));

            return bundle;
        }

        /********************************************************************************
        * FUNCTION     : BuildPatientElement
        * DESCRIPTION  : Builds the Patient XML element based on mapping rules and data.
        *
        * PARAMETERS   : ParsedFlatFile parsedFile : Parsed flat file containing Patient data.
        *
        * RETURNS      : XElement : Patient XML element.
        *********************************************************************************/
        private XElement BuildPatientElement(ParsedFlatFile parsedFile)
        {
            var patientElement = new XElement(_fhirNamespace + "Patient");

            foreach (var rule in _mappingRules)
            {
                if (rule.Section.Equals("Patient", StringComparison.OrdinalIgnoreCase) &&
                    parsedFile.Patient.Fields.ContainsKey(rule.FlatFileKey))
                {
                    var value = parsedFile.Patient.Fields[rule.FlatFileKey];

                    if (rule.FhirPath.EndsWith("identifier.value", StringComparison.OrdinalIgnoreCase))
                    {
                        patientElement.Add(new XElement(_fhirNamespace + "identifier",
                            new XElement(_fhirNamespace + "value", new XAttribute("value", value))));
                    }
                    else if (rule.FhirPath.EndsWith("address.postalCode", StringComparison.OrdinalIgnoreCase))
                    {
                        patientElement.Add(new XElement(_fhirNamespace + "address",
                            new XElement(_fhirNamespace + "postalCode", new XAttribute("value", value))));
                    }
                }
            }

            return patientElement;
        }

        /********************************************************************************
        * FUNCTION     : BuildEncounterElement
        * DESCRIPTION  : Builds the Encounter XML element based on mapping rules and data.
        *
        * PARAMETERS   : ParsedFlatFile parsedFile : Parsed flat file containing Encounter data.
        *
        * RETURNS      : XElement : Encounter XML element.
        *********************************************************************************/
        private XElement BuildEncounterElement(ParsedFlatFile parsedFile)
        {
            var encounterElement = new XElement(_fhirNamespace + "Encounter");

            foreach (var rule in _mappingRules)
            {
                if (rule.Section.Equals("Encounter", StringComparison.OrdinalIgnoreCase) &&
                    parsedFile.Encounter.Fields.ContainsKey(rule.FlatFileKey))
                {
                    var value = parsedFile.Encounter.Fields[rule.FlatFileKey];

                    if (rule.FhirPath.EndsWith("period.start", StringComparison.OrdinalIgnoreCase))
                    {
                        encounterElement.Add(new XElement(_fhirNamespace + "period",
                            new XElement(_fhirNamespace + "start", new XAttribute("value", value))));
                    }
                }
            }

            return encounterElement;
        }

        /********************************************************************************
        * FUNCTION     : BuildQuestionnaireResponseElement
        * DESCRIPTION  : Builds the QuestionnaireResponse XML element based on Assessment sections.
        *
        * PARAMETERS   : ParsedFlatFile parsedFile : Parsed flat file containing Assessment data.
        *
        * RETURNS      : XElement : QuestionnaireResponse XML element.
        *********************************************************************************/
        private XElement BuildQuestionnaireResponseElement(ParsedFlatFile parsedFile)
        {
            var questionnaireElement = new XElement(_fhirNamespace + "QuestionnaireResponse");

            foreach (var section in parsedFile.AssessmentSections)
            {
                foreach (var field in section.Value)
                {
                    questionnaireElement.Add(new XElement(_fhirNamespace + "item",
                        new XElement(_fhirNamespace + "linkId", new XAttribute("value", field.Key)),
                        new XElement(_fhirNamespace + "answer",
                            new XElement(_fhirNamespace + "valueString", new XAttribute("value", field.Value)))
                    ));
                }
            }

            return questionnaireElement;
        }

        /********************************************************************************
        * FUNCTION     : CreateEntry
        * DESCRIPTION  : Wraps a resource element into an entry element for inclusion in the Bundle.
        *
        * PARAMETERS   : XElement resourceElement : FHIR resource element to be wrapped.
        *
        * RETURNS      : XElement : Entry XML element containing the resource.
        *********************************************************************************/
        private XElement CreateEntry(XElement resourceElement)
        {
            return new XElement(_fhirNamespace + "entry",
                new XElement(_fhirNamespace + "resource", resourceElement));
        }
    }
}
