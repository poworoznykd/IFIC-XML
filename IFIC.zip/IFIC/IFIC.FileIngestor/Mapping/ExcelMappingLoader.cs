﻿/************************************************************************************
* FILE          : ExcelMappingLoader.cs
* PROJECT       : IFIC-XML
* PROGRAMMER    : Darryl Poworoznyk
* FIRST VERSION : 2025-08-01
* DESCRIPTION   : Provides functionality to load and merge field-to-FHIR mapping rules 
*                 from CIHI Excel sources into MappingRule objects for Patient, Encounter, 
*                 and Assessment sections. Incorporates mandatory elements, business 
*                 rules, and allowed values.
************************************************************************************/

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using IFIC.FileIngestor.Models;
using ClosedXML.Excel;

namespace IFIC.FileIngestor.Mapping
{
    /********************************************************************************
    * CLASS NAME   : ExcelMappingLoader
    * DESCRIPTION  : Reads mapping definitions from CIHI Excel files (mapping, mandatory 
    *                elements, business rules, and value sets) and returns a unified list 
    *                of MappingRule objects.
    *********************************************************************************/
    public class ExcelMappingLoader
    {
        /********************************************************************************
        * FUNCTION     : LoadMappings
        * DESCRIPTION  : Loads mapping rules from CIHI Excel files:
        *                - FHIR mapping file
        *                - Mandatory element matrix
        *                - Business rules
        *                - Value sets
        *
        * PARAMETERS   : string mappingFilePath          : Path to the FHIR mapping file.
        *                string mandatoryMatrixFilePath  : Path to the mandatory element matrix.
        *                string rulesFilePath            : Path to the business rules file.
        *                string valueSetFilePath         : Path to the value set file.
        *
        * RETURNS      : List<MappingRule> : Combined mapping rules.
        *********************************************************************************/
        public List<MappingRule> LoadMappings(
            string mappingFilePath,
            string mandatoryMatrixFilePath,
            string rulesFilePath,
            string valueSetFilePath)
        {
            if (!File.Exists(mappingFilePath))
            {
                throw new FileNotFoundException("FHIR mapping file not found.", mappingFilePath);
            }

            var mappingRules = new List<MappingRule>();

            // Load base mappings
            using (var workbook = new XLWorkbook(mappingFilePath))
            {
                var worksheet = workbook.Worksheet(1);
                var rows = worksheet.RangeUsed().RowsUsed().Skip(1); // Skip header row

                foreach (var row in rows)
                {
                    var section = row.Cell(1).GetString().Trim();
                    var flatKey = row.Cell(2).GetString().Trim();
                    var fhirPath = row.Cell(3).GetString().Trim();
                    var dataType = row.Cell(4).GetString().Trim();

                    if (string.IsNullOrEmpty(flatKey) || string.IsNullOrEmpty(fhirPath))
                    {
                        continue;
                    }

                    mappingRules.Add(new MappingRule
                    {
                        Section = section,
                        FlatFileKey = flatKey,
                        FhirPath = fhirPath,
                        DataType = dataType,
                        IsMandatory = false,
                        ValidationRule = string.Empty
                    });
                }
            }

            // Merge Mandatory Matrix
            var mandatoryFields = File.Exists(mandatoryMatrixFilePath)
                ? LoadMandatoryFields(mandatoryMatrixFilePath)
                : new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            foreach (var rule in mappingRules)
            {
                if (mandatoryFields.Contains($"{rule.Section}|{rule.FlatFileKey}"))
                {
                    rule.IsMandatory = true;
                }
            }

            // Merge Business Rules
            var rulesDict = File.Exists(rulesFilePath)
                ? LoadBusinessRules(rulesFilePath)
                : new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

            foreach (var rule in mappingRules)
            {
                if (rulesDict.TryGetValue(rule.FlatFileKey, out var text))
                {
                    rule.ValidationRule = text;
                }
            }

            // Merge Allowed Values
            var valueSets = File.Exists(valueSetFilePath)
                ? LoadAllowedValues(valueSetFilePath)
                : new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);

            foreach (var rule in mappingRules)
            {
                if (valueSets.TryGetValue(rule.FlatFileKey, out var allowed))
                {
                    rule.AllowedValues = allowed;
                }
            }

            return mappingRules;
        }

        /// <summary>
        /// Loads mapping rules from a specified mapping file, using default paths for mandatory elements,
        /// </summary>
        /// <param name="mappingFilePath"></param>
        /// <returns></returns>
        public List<MappingRule> LoadMappings(string mappingFilePath)
        {
            return LoadMappings(mappingFilePath, null, null, null);
        }


        /********************************************************************************
        * FUNCTION     : LoadMandatoryFields
        * DESCRIPTION  : Reads mandatory elements from CIHI mandatory element matrix.
        *
        * PARAMETERS   : string filePath : Path to mandatory matrix file.
        *
        * RETURNS      : HashSet<string> : Composite keys in "Section|Key" format.
        *********************************************************************************/
        private HashSet<string> LoadMandatoryFields(string filePath)
        {
            var result = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            using (var workbook = new XLWorkbook(filePath))
            {
                var worksheet = workbook.Worksheet(1);
                var rows = worksheet.RangeUsed().RowsUsed().Skip(1);

                foreach (var row in rows)
                {
                    var section = row.Cell(1).GetString().Trim();
                    var key = row.Cell(2).GetString().Trim();
                    var mandatory = row.Cell(3).GetString().Trim();

                    if (mandatory.Equals("Yes", StringComparison.OrdinalIgnoreCase))
                    {
                        result.Add($"{section}|{key}");
                    }
                }
            }
            return result;
        }

        /********************************************************************************
        * FUNCTION     : LoadBusinessRules
        * DESCRIPTION  : Loads business rules from CIHI rules Excel file.
        *
        * PARAMETERS   : string filePath : Path to rules file.
        *
        * RETURNS      : Dictionary<string, string> : Key = FlatFileKey, Value = Rule text.
        *********************************************************************************/
        private Dictionary<string, string> LoadBusinessRules(string filePath)
        {
            var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            using (var workbook = new XLWorkbook(filePath))
            {
                var worksheet = workbook.Worksheet(1);
                var rows = worksheet.RangeUsed().RowsUsed().Skip(1);

                foreach (var row in rows)
                {
                    var key = row.Cell(1).GetString().Trim();
                    var text = row.Cell(2).GetString().Trim();

                    if (!string.IsNullOrEmpty(key) && !string.IsNullOrEmpty(text))
                    {
                        result[key] = text;
                    }
                }
            }
            return result;
        }

        /********************************************************************************
        * FUNCTION     : LoadAllowedValues
        * DESCRIPTION  : Reads allowed values from CIHI Code System and Value Set file.
        *
        * PARAMETERS   : string filePath : Path to allowed values Excel file.
        *
        * RETURNS      : Dictionary<string, List<string>> : Key = FlatFileKey, Values = Allowed codes.
        *********************************************************************************/
        private Dictionary<string, List<string>> LoadAllowedValues(string filePath)
        {
            var result = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);
            using (var workbook = new XLWorkbook(filePath))
            {
                var worksheet = workbook.Worksheet(1);
                var rows = worksheet.RangeUsed().RowsUsed().Skip(1);

                foreach (var row in rows)
                {
                    var key = row.Cell(1).GetString().Trim();
                    var value = row.Cell(2).GetString().Trim();

                    if (!string.IsNullOrEmpty(key) && !string.IsNullOrEmpty(value))
                    {
                        if (!result.ContainsKey(key))
                        {
                            result[key] = new List<string>();
                        }
                        result[key].Add(value);
                    }
                }
            }
            return result;
        }
    }
}
