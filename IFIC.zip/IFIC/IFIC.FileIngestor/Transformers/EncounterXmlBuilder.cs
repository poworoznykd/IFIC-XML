﻿using IFIC.FileIngestor.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace IFIC.FileIngestor.Transformers
{
    public class EncounterXmlBuilder
    {
        private static readonly XNamespace ns = "http://hl7.org/fhir";
        public string StartDate { get; set; }
        private List<XElement> CreateICodeA7Elements(ParsedFlatFile parsedFile)
        {
            var coverageCodes = new[] { "iA7a", "iA7b", "iA7c", "iA7d", "iA7e", "iA7f", "iA7g", "iA7h", "iA7i", "iA7j", "iA7k" };
            var coverageContainedElements = new List<XElement>();

            // Determine if assessment type contains "return"
            string axType = parsedFile.Admin.TryGetValue("axType", out var axTypeValue) ? axTypeValue : string.Empty;
            bool isReturnAssessment = axType.IndexOf("return", StringComparison.OrdinalIgnoreCase) >= 0;

            // Choose appropriate field for start date
            string dateFieldKey = isReturnAssessment ? "A12" : "B2";
            StartDate = parsedFile.Encounter.TryGetValue(dateFieldKey, out var rawDate) && !string.IsNullOrWhiteSpace(rawDate)
                ? rawDate
                : "2017-01-01"; // fallback if B2 or A12 missing

            foreach (var code in coverageCodes)
            {
                if (parsedFile.Encounter.TryGetValue(code, out var value) && !string.IsNullOrWhiteSpace(value))
                {
                    // Assign type code - customize as needed per code
                    string typeCode = code == "iA7a" ? "INPUBLICPOL" : "pay";

                    coverageContainedElements.Add(
                        new XElement(ns + "contained",
                            new XElement(ns + "Coverage",
                                new XElement(ns + "id", new XAttribute("value", $"coverage-{code}")),
                                new XElement(ns + "meta",
                                    new XElement(ns + "profile", new XAttribute("value", "http://cihi.ca/fhir/irrs/StructureDefinition/irrs-coverage"))
                                ),
                                new XElement(ns + "type",
                                    new XElement(ns + "coding",
                                        new XElement(ns + "code", new XAttribute("value", typeCode))
                                    )
                                ),
                                new XElement(ns + "period",
                                    new XElement(ns + "start", new XAttribute("value", StartDate))
                                )
                            )
                        )
                    );
                }
            }

            return coverageContainedElements;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="parsedFile"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentNullException"></exception>
        public XDocument BuildEncounterBundle(ParsedFlatFile parsedFile)
        {
            if (parsedFile == null)
            {
                throw new ArgumentNullException(nameof(parsedFile), "Parsed flat file cannot be null.");
            }

            // Generate unique IDs for resources
            string bundleId = Guid.NewGuid().ToString();
            string encounterId = Guid.NewGuid().ToString();
            string patientId = Guid.NewGuid().ToString();
            var coverageCodes = new[] { "iA7a", "iA7b", "iA7c", "iA7d", "iA7e", "iA7f", "iA7g", "iA7h", "iA7i", "iA7j", "iA7k" };
            // Extract encounter values from flat file

            parsedFile.Encounter.TryGetValue("B5A", out var admittedFrom);
            parsedFile.Encounter.TryGetValue("B2", out var stayStartDate);
            parsedFile.Encounter.TryGetValue("R1", out var stayEndDate);
            parsedFile.Encounter.TryGetValue("B5B", out var admittedFromFacilityNumber);
            parsedFile.Encounter.TryGetValue("OrgID", out var orgId);
            parsedFile.Encounter.TryGetValue("R2", out var livingStatus);
            parsedFile.Encounter.TryGetValue("R4", out var dischargedToFacilityNumber);

            // Create Bundle document
            var bundle = new XElement(ns + "Bundle", new XAttribute("xmlns", ns),
                new XElement(ns + "id", new XAttribute("value", bundleId)),
                new XElement(ns + "type", new XAttribute("value", "transaction")),

                new XElement(ns + "entry",
                    new XElement(ns + "fullUrl", new XAttribute("value", $"urn:uuid:{encounterId}")),
                    new XElement(ns + "resource",
                        new XElement(ns + "Encounter",
                        new XAttribute("xmlns", ns),
                            new XElement(ns + "id", new XAttribute("value", encounterId)),
                            new XElement(ns + "meta",
                                new XElement(ns + "profile",
                                    new XAttribute("value", "http://cihi.ca/fhir/irrs/StructureDefinition/irrs-encounter")
                                )
                            ),

                            // contained - admitted from
                            !string.IsNullOrWhiteSpace(admittedFrom)
                            ? new XElement(ns + "contained",
                                new XElement(ns + "Location",
                                    new XElement(ns + "id",
                                        new XAttribute("value", "admittedFrom")
                                    ),
                                    new XElement(ns + "meta",
                                        new XElement(ns + "profile",
                                            new XAttribute("value", "http://cihi.ca/fhir/irrs/StructureDefinition/irrs-location-admission")
                                        )
                                    ),
                                    new XElement(ns + "type",
                                        new XElement(ns + "coding",
                                            new XElement(ns + "code",
                                                new XAttribute("value", admittedFrom)
                                            )
                                        )
                                    ),
                                    !string.IsNullOrWhiteSpace(admittedFromFacilityNumber)
                                    ? new XElement(ns + "managingOrganization",
                                        new XElement(ns + "identifier",
                                            new XElement(ns + "value", new XAttribute("value", admittedFromFacilityNumber))
                                        )
                                    ) : null
                                )
                            )
                            : null,

                        // contained - discharged to
                        !string.IsNullOrWhiteSpace(orgId)
                            ? new XElement(ns + "contained",
                                new XElement(ns + "Location",
                                    new XElement(ns + "id",
                                        new XAttribute("value", "dischargedTo")
                                    ),
                                    new XElement(ns + "meta",
                                        new XElement(ns + "profile",
                                            new XAttribute("value", "http://cihi.ca/fhir/irrs/StructureDefinition/irrs-location-discharge")
                                        )
                                    ),
                                    new XElement(ns + "type",
                                        new XElement(ns + "coding",
                                            new XElement(ns + "code",
                                                new XAttribute("value", livingStatus)
                                            )
                                        )
                                    ),
                                    !string.IsNullOrWhiteSpace(dischargedToFacilityNumber)
                                    ? new XElement(ns + "managingOrganization",
                                        new XElement(ns + "identifier",
                                            new XElement(ns + "value", new XAttribute("value", dischargedToFacilityNumber))
                                        )
                                    ) : null
                                )
                            )
                            : null,
            #region Commented Code
                            //// contained - program type 1
                            //!string.IsNullOrWhiteSpace(patientId) &&
                            //!string.IsNullOrWhiteSpace(stayStartDate) &&
                            //!string.IsNullOrWhiteSpace(stayEndDate)
                            //    ? new XElement(ns + "contained",
                            //        new XElement(ns + "Encounter",
                            //            new XElement(ns + "id",
                            //                new XAttribute("value", "programType1")
                            //            ),
                            //            new XElement(ns + "meta",
                            //                new XElement(ns + "profile",
                            //                    new XAttribute("value", "http://cihi.ca/fhir/irrs/StructureDefinition/irrs-encounter")
                            //                )
                            //            ),
                            //            new XElement(ns + "status",
                            //                new XElement(ns + "profile",
                            //                    new XAttribute("value", "http://cihi.ca/fhir/irrs/StructureDefinition/irrs-encounter")
                            //                )
                            //            ),
                            //            new XElement(ns + "type",
                            //                new XElement(ns + "coding",
                            //                    new XElement(ns + "code",
                            //                        new XAttribute("value", "PRT123") 
                            //                    )
                            //                )
                            //            ),
                            //            new XElement(ns + "subject",
                            //                new XElement(ns + "reference",
                            //                    new XAttribute("value", $"Patient/{patientId}")
                            //                )
                            //            ),
                            //            new XElement(ns + "period",
                            //                new XElement(ns + "start",
                            //                    new XAttribute("value", stayStartDate)
                            //                ),
                            //                new XElement(ns + "end",
                            //                    new XAttribute("value", stayEndDate)
                            //                )
                            //            ),
                            //            new XElement(ns + "serviceProvider",
                            //                new XElement(ns + "identifier",
                            //                    new XElement(ns + "system",
                            //                        new XAttribute("value", "http://cihi.ca/fhir/NamingSystem/on-ministry-of-health-and-long-term-care-submission-identifier")
                            //                    ),
                            //                    new XElement(ns + "value",
                            //                        new XAttribute("value", orgId)
                            //                    )
                            //                )
                            //            )
                            //        )
                            //    )
                            //    : null,

                            // contained - ?
                            //!string.IsNullOrWhiteSpace(admittedFrom)
                            //    ? new XElement(ns + "contained",
                            //        new XElement(ns + "Location",
                            //            new XElement(ns + "id",
                            //                new XAttribute("value", "misCode")
                            //            ),
                            //            new XElement(ns + "meta",
                            //                new XElement(ns + "profile",
                            //                    new XAttribute("value", "http://cihi.ca/fhir/irrs/StructureDefinition/irrs-location-mis-code")
                            //                )
                            //            ),
                            //            new XElement(ns + "type",
                            //                new XElement(ns + "coding",
                            //                    new XElement(ns + "code",
                            //                        new XAttribute("value", admittedFromFacilityNumber) 
                            //                    )
                            //                )
                            //            ),
                            //                new XElement(ns + "physicalType",
                            //                new XElement(ns + "coding",
                            //                    new XElement(ns + "code",
                            //                        new XAttribute("value", "wa")
                            //                    )
                            //                )
                            //            )
                            //        )
                            //    )
                            //    : null,

                            //// contained - Bed Type
                            //!string.IsNullOrWhiteSpace(admittedFrom)//TODO - hardcoded? (admittedFrom = Program Type 1?)
                            //    ? new XElement(ns + "contained",
                            //        new XElement(ns + "Location",
                            //            new XElement(ns + "id",
                            //                new XAttribute("value", "bedType")
                            //            ),
                            //            new XElement(ns + "meta",
                            //                new XElement(ns + "profile",
                            //                    new XAttribute("value", "http://cihi.ca/fhir/irrs/StructureDefinition/irrs-location-bed-type")
                            //                )
                            //            ),
                            //            new XElement(ns + "type",
                            //                new XElement(ns + "coding",
                            //                    new XElement(ns + "code",
                            //                        new XAttribute("value", "CCCF")//TODO- hardcoded? (CCCF = Complex Continuing Care Facility
                            //                    )
                            //                )
                            //            ),
                            //                new XElement(ns + "physicalType",
                            //                new XElement(ns + "coding",
                            //                    new XElement(ns + "code",
                            //                        new XAttribute("value", "bd")//TODO - hard coded? (bd = Bed Type)
                            //                    )
                            //                )
                            //            )
                            //        )
                            //    )
                            //    : null,
            #endregion
                            // contained - Payment Source
                            new XElement(ns + "contained",
                                new XElement(ns + "Account",
                                    new XElement(ns + "id", new XAttribute("value", "paymentSource")),
                                    new XElement(ns + "meta",
                                        new XElement(ns + "profile", new XAttribute("value", "http://cihi.ca/fhir/irrs/StructureDefinition/irrs-account"))
                                    ),
                                    new XElement(ns + "type",
                                        new XElement(ns + "coding",
                                            new XElement(ns + "code", new XAttribute("value", "PBILLACCT"))
                                        )
                                    ),
                                    // Dynamically add <coverage> elements inside Account
                                    coverageCodes
                                        .Where(code => parsedFile.Encounter.ContainsKey(code) && !string.IsNullOrWhiteSpace(parsedFile.Encounter[code]))
                                        .Select(code => new XElement(ns + "coverage",
                                            new XElement(ns + "coverage",
                                                new XElement(ns + "reference", new XAttribute("value", $"#coverage-{code}"))
                                            )
                                        ))
                                )
                            ),
                            CreateICodeA7Elements(parsedFile),
            #region Commented Code 2
                            //// contained - Reference to the contained program type

                            //new XElement(ns + "extension",
                            //    new XAttribute("url", "http://cihi.ca/fhir/irrs/StructureDefinition/irrs-ext-includes"),
                            //    new XElement(ns + "valueReference",
                            //        new XElement(ns + "reference",
                            //            new XAttribute("value", "#programType1")
                            //        )
                            //    )
                            //),

                            ////planned
                            //new XElement(ns + "status",
                            //    new XAttribute("value", "planned")
                            //),


            #endregion
                            // contained - Patient ID
                            !string.IsNullOrWhiteSpace(patientId)
                                ? new XElement(ns + "subject",
                                    new XElement(ns + "reference",
                                        new XAttribute("value", $"Patient/{patientId}")
                                    )
                                )
                                : null,

                            // period
                            !string.IsNullOrWhiteSpace(StartDate) || !string.IsNullOrWhiteSpace(stayEndDate)
                                ? new XElement(ns + "period",
                                    new XElement(ns + "start",
                                        new XAttribute("value", StartDate)
                                    ),
                                    new XElement(ns + "end",
                                        new XAttribute("value", stayEndDate)
                                    )
                                )
                                : null,
            #region Commented Code 3
                            //new XElement(ns + "Account",
                            //    new XElement(ns + "id",
                            //        new XAttribute("value", "#paymentSource")
                            //    )
                            //),

                            ////Hospitalization
                            //!string.IsNullOrWhiteSpace(admittedFrom)
                            //? new XElement(ns + "hospitalization",
                            //    new XElement(ns + "origin",
                            //        new XElement(ns + "reference",
                            //            new XAttribute("value", "#admittedFrom")
                            //        )
                            //    ),
                            //    new XElement(ns + "reAdmission",
                            //        new XElement(ns + "coding",
                            //            new XAttribute("code", 1)//TODO - hard coded? (1 = Yes, 2 = No, 3 = Unknown?)
                            //        )
                            //    ),
                            //    new XElement(ns + "destination",
                            //            new XAttribute("value", "#dischargedTo")
                            //    )
                            //)
                            //: null,

                            ////MIS Function Centre
                            //!string.IsNullOrWhiteSpace(stayStartDate) && !string.IsNullOrWhiteSpace(stayEndDate)
                            //? new XElement(ns + "location",
                            //    new XElement(ns + "location",
                            //        new XElement(ns + "reference",
                            //            new XAttribute("value", "#misCode")
                            //        )
                            //    ),
                            //    new XElement(ns + "period",
                            //        new XElement(ns + "start",
                            //            new XAttribute("value", stayStartDate)
                            //        ),
                            //        new XElement(ns + "end",
                            //            new XAttribute("value", stayEndDate)
                            //        )
                            //    )
                            //)
                            //: null,

                            ////Bed Type
                            //!string.IsNullOrWhiteSpace(stayStartDate) && !string.IsNullOrWhiteSpace(stayEndDate)
                            //? new XElement(ns + "location",
                            //    new XElement(ns + "location",
                            //        new XElement(ns + "reference",
                            //            new XAttribute("value", "#bedType")
                            //        )
                            //    ),
                            //    new XElement(ns + "period",
                            //        new XElement(ns + "start",
                            //            new XAttribute("value", stayStartDate)
                            //        ),
                            //        new XElement(ns + "end",
                            //            new XAttribute("value", stayEndDate)
                            //        )
                            //    )
                            //)
                            //: null,
            #endregion
                            // Faciltiy/agnecy identifier this encounter is related to
                            new XElement(ns + "serviceProvider",
                                new XElement(ns + "identifier",
                                    new XElement(ns + "system", new XAttribute("value", "http://cihi.ca/fhir/NamingSystem/on-ministry-of-health-and-long-term-care-submission-identifier")),
                                    new XElement(ns + "value", new XAttribute("value", orgId))
                                )
                            )
                        )
                    ),
                    new XElement(ns + "request",
                        new XElement(ns + "method", new XAttribute("value", "POST")),
                        new XElement(ns + "url", new XAttribute("value", "Encounter"))
                    )
                )
            );

            return new XDocument(new XDeclaration("1.0", "UTF-8", "yes"), bundle);
        }
    }
}
