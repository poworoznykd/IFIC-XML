﻿/************************************************************************************
* FILE          : FlatFileParser.cs
* PROJECT       : IFIC - IRRS/FHIR Intermediary Component
* PROGRAMMER    : Darryl Poworoznyk
* FIRST VERSION : 2025-08-01
* DESCRIPTION   :
*   Parses flat files into structured sections for transformation.
************************************************************************************/

using System;
using System.Collections.Generic;
using System.IO;
using IFIC.FileIngestor.Models;

namespace IFIC.FileIngestor.Parsers
{
    public class FlatFileParser
    {
        public ParsedFlatFile ParseFile(string filePath)
        {
            if (!File.Exists(filePath))
                throw new FileNotFoundException("Flat file not found.", filePath);

            var parsed = new ParsedFlatFile();
            string currentSection = null;

            foreach (var lineRaw in File.ReadLines(filePath))
            {
                var line = lineRaw.Trim();
                if (string.IsNullOrWhiteSpace(line)) continue;

                if (line.StartsWith("[") && line.EndsWith("]"))
                {
                    currentSection = line.Trim('[', ']');
                    continue;
                }

                if (currentSection == null) continue;

                var parts = line.Split('=', 2);
                if (parts.Length != 2) continue;

                var key = parts[0].Trim();
                var value = parts[1].Trim();

                switch (currentSection.ToUpperInvariant())
                {
                    case "ADMIN": parsed.Admin.Fields[key] = value; break;
                    case "PATIENT": parsed.Patient.Fields[key] = value; break;
                    case "ENCOUNTER": parsed.Encounter.Fields[key] = value; break;
                    default:
                        if (!parsed.AssessmentSections.ContainsKey(currentSection))
                            parsed.AssessmentSections[currentSection] = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                        parsed.AssessmentSections[currentSection][key] = value;
                        break;
                }
            }
            return parsed;
        }
    }
}
