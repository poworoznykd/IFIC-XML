/************************************************************************************
* FILE          : ParserTests.cs
* PROJECT       : IFIC-XML
* PROGRAMMER    : Your Name
* FIRST VERSION : 2025-08-01
* DESCRIPTION   : This file contains unit tests for the FlatFileParser class. The tests
*                 verify the correct parsing of ADMIN, PATIENT, ENCOUNTER, and assessment
*                 sections from a Clarity LTCF flat file into a ParsedFlatFile object.
************************************************************************************/

using System.IO;
using Xunit;
using FluentAssertions;
using IFIC.FileIngestor.Parsers;

namespace IFIC.Tests
{
    /********************************************************************************
    * CLASS NAME   : ParserTests
    * DESCRIPTION  : Contains test methods for validating the behavior of FlatFileParser.
    *********************************************************************************/
    public class ParserTests
    {
        private readonly string _testDataPath;

        /********************************************************************************
        * CONSTRUCTOR  : ParserTests
        * DESCRIPTION   : Initializes the test class and sets the path to the TestData folder.
        *********************************************************************************/
        public ParserTests()
        {
            _testDataPath = Path.Combine(Directory.GetCurrentDirectory(), "TestData");
            if (!Directory.Exists(_testDataPath))
            {
                Directory.CreateDirectory(_testDataPath);
            }
        }

        /********************************************************************************
        * FUNCTION      : Parse_ShouldReadSectionsCorrectly
        * DESCRIPTION   : Validates that FlatFileParser correctly identifies and parses
        *                 all sections and their respective fields from the flat file.
        *********************************************************************************/
        [Fact]
        public void Parse_ShouldReadSectionsCorrectly()
        {
            // Arrange
            var parser = new FlatFileParser();
            var testFile = Path.Combine(_testDataPath, "SampleInput.dat");
            File.WriteAllText(testFile, GetSampleFlatFileContent());

            // Act
            var result = parser.ParseFile(testFile);

            // Assert
            result.Should().NotBeNull();

            // Validate ADMIN section
            result.Admin.Fields.Should().ContainKey("rec_id").WhoseValue.Should().Be("2025070041");
            result.Admin.Fields.Should().ContainKey("axType").WhoseValue.Should().Be("01");

            // Validate PATIENT section
            result.Patient.Fields.Should().ContainKey("A5A").WhoseValue.Should().Be("1234567897");
            result.Patient.Fields.Should().ContainKey("A5B").WhoseValue.Should().Be("ON");

            // Validate ENCOUNTER section
            result.Encounter.Fields.Should().ContainKey("B2").WhoseValue.Should().Be("2025-06-01");

            // Validate Assessment Section
            result.AssessmentSections.Should().ContainKey("SECTION A");
            result.AssessmentSections["SECTION A"].Should().ContainKey("A4").WhoseValue.Should().Be("T");
            result.AssessmentSections["SECTION A"].Should().ContainKey("A7").WhoseValue.Should().Be("Y");
        }

        /********************************************************************************
        * FUNCTION      : Parse_ShouldThrowIfFileNotFound
        * DESCRIPTION   : Ensures that FlatFileParser throws a FileNotFoundException when
        *                 the specified file path does not exist.
        *********************************************************************************/
        [Fact]
        public void Parse_ShouldThrowIfFileNotFound()
        {
            // Arrange
            var parser = new FlatFileParser();
            var nonExistentFile = Path.Combine(_testDataPath, "DoesNotExist.dat");

            // Act & Assert
            Assert.Throws<FileNotFoundException>(() => parser.ParseFile(nonExistentFile));
        }

        /********************************************************************************
        * FUNCTION      : GetSampleFlatFileContent
        * DESCRIPTION   : Provides sample flat file content used in test cases.
        *
        * RETURNS       : string : Sample flat file text.
        *********************************************************************************/
        private string GetSampleFlatFileContent()
        {
            return @"
[ADMIN]
rec_id=2025070041
axType=01
fiscal=2025

[PATIENT]
OrgID=58888
A5A=1234567897
A5B=ON

[ENCOUNTER]
OrgID=58888
B2=2025-06-01

[SECTION A]
A4=T
A7=Y
";
        }
    }
}
