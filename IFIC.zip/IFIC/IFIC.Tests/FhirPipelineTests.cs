﻿/************************************************************************************
* FILE          : FhirPipelineTests.cs
* PROJECT       : IFIC-XML Tests
* PROGRAMMER    : Your Name
* FIRST VERSION : 2025-08-02
* DESCRIPTION   : Unit tests for the FhirPipeline integration flow.
************************************************************************************/

using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using ClosedXML.Excel;
using FluentAssertions;
using IFIC.FileIngestor.Models;
using IFIC.FileIngestor.Pipeline;
using Microsoft.Extensions.Configuration;
using Xunit;
using static Org.BouncyCastle.Math.EC.ECCurve;

namespace IFIC.Tests
{
    public class FhirPipelineTests
    {
        private readonly string _testOutputDir;

        public FhirPipelineTests()
        {
            _testOutputDir = Path.Combine(Directory.GetCurrentDirectory(), "TestOutput");
            if (!Directory.Exists(_testOutputDir))
            {
                Directory.CreateDirectory(_testOutputDir);
            }
        }

      
    }
}
