﻿/************************************************************************************
* FILE          : ExcelMappingLoaderTests.cs
* PROJECT       : IFIC-XML Tests
* PROGRAMMER    : Darryl Poworoznyk
* FIRST VERSION : 2025-08-02
* DESCRIPTION   : Unit tests for ExcelMappingLoader to validate mapping file parsing
*                 and merging of multiple Excel sources for FHIR transformation rules.
************************************************************************************/

using System;
using System.Collections.Generic;
using System.IO;
using ClosedXML.Excel;
using FluentAssertions;
using IFIC.FileIngestor.Mapping;
using IFIC.FileIngestor.Models;
using Xunit;

namespace IFIC.Tests
{
    /// <summary>
    /// Tests the functionality of ExcelMappingLoader for reading mapping configurations.
    /// </summary>
    public class ExcelMappingLoaderTests
    {
        private readonly string _testDataDir;

        /// <summary>
        /// Initializes the directory for storing test files.
        /// </summary>
        public ExcelMappingLoaderTests()
        {
            _testDataDir = Path.Combine(Directory.GetCurrentDirectory(), "TestData");
            if (!Directory.Exists(_testDataDir))
            {
                Directory.CreateDirectory(_testDataDir);
            }
        }

        /// <summary>
        /// Verifies that LoadMappings correctly loads mapping rules from the primary Excel file.
        /// </summary>
        [Fact]
        public void LoadMappings_ShouldLoadSingleSourceCorrectly()
        {
            // Arrange
            string mappingFilePath = Path.Combine(_testDataDir, $"Mapping_{Guid.NewGuid()}.xlsx");
            CreateMappingFile(mappingFilePath);

            var loader = new ExcelMappingLoader();

            // Act
            List<MappingRule> rules = loader.LoadMappings(mappingFilePath);

            // Assert
            rules.Should().NotBeNull();
            rules.Should().BeOfType<List<MappingRule>>();
        }

        /// <summary>
        /// Verifies that LoadMappings merges rules from multiple Excel sources (mocked for now).
        /// </summary>
        [Fact]
        public void LoadMappings_ShouldMergeAllSourcesCorrectly()
        {
            // Arrange
            string mappingFilePath = Path.Combine(_testDataDir, $"Mapping_{Guid.NewGuid()}.xlsx");
            string mandatoryMatrixFilePath = Path.Combine(_testDataDir, $"MandatoryMatrix_{Guid.NewGuid()}.xlsx");
            string rulesFilePath = Path.Combine(_testDataDir, $"Rules_{Guid.NewGuid()}.xlsx");
            string valueSetFilePath = Path.Combine(_testDataDir, $"ValueSet_{Guid.NewGuid()}.xlsx");

            CreateMappingFile(mappingFilePath);
            CreateMappingFile(mandatoryMatrixFilePath);
            CreateMappingFile(rulesFilePath);
            CreateMappingFile(valueSetFilePath);

            var loader = new ExcelMappingLoader();

            // Act
            List<MappingRule> rules = loader.LoadMappings(mappingFilePath, mandatoryMatrixFilePath, rulesFilePath, valueSetFilePath);

            // Assert
            rules.Should().NotBeNull();
            rules.Should().BeOfType<List<MappingRule>>();
        }

        /// <summary>
        /// Creates a simple Excel mapping file for test purposes.
        /// </summary>
        /// <param name="filePath">Path to save the Excel file.</param>
        private void CreateMappingFile(string filePath)
        {
            using (var wb = new XLWorkbook())
            {
                var ws = wb.AddWorksheet("Mappings");
                ws.Cell(1, 1).Value = "Section";
                ws.Cell(1, 2).Value = "FlatFileKey";
                ws.Cell(1, 3).Value = "FhirPath";

                ws.Cell(2, 1).Value = "Patient";
                ws.Cell(2, 2).Value = "A5A";
                ws.Cell(2, 3).Value = "Patient.identifier.value";

                ws.Cell(3, 1).Value = "Encounter";
                ws.Cell(3, 2).Value = "B2";
                ws.Cell(3, 3).Value = "Encounter.period.start";

                wb.SaveAs(filePath);
            }
        }
    }
}
