﻿/************************************************************************************
* FILE          : FlatFileParserTests.cs
* PROJECT       : IFIC-XML
* PROGRAMMER    : Your Name
* FIRST VERSION : 2025-08-02
* DESCRIPTION   : Contains unit tests for the FlatFileParser class. These tests ensure
*                 proper parsing of Admin, Patient, Encounter, and Assessment sections.
************************************************************************************/

using System;
using System.Collections.Generic;
using System.IO;
using FluentAssertions;
using IFIC.FileIngestor.Models;
using IFIC.FileIngestor.Parsers;
using Xunit;

namespace IFIC.Tests
{
    /********************************************************************************
    * CLASS NAME   : FlatFileParserTests
    * DESCRIPTION  : Unit tests for verifying the functionality of FlatFileParser.
    *********************************************************************************/
    public class FlatFileParserTests
    {
        private readonly string _testDataDir;

        /********************************************************************************
        * CONSTRUCTOR  : FlatFileParserTests
        * DESCRIPTION   : Initializes the test data directory.
        *********************************************************************************/
        public FlatFileParserTests()
        {
            _testDataDir = Path.Combine(Directory.GetCurrentDirectory(), "TestData");
            if (!Directory.Exists(_testDataDir))
            {
                Directory.CreateDirectory(_testDataDir);
            }
        }

        /********************************************************************************
        * FUNCTION      : ParseFile_ShouldParseAllSectionsCorrectly
        * DESCRIPTION   : Ensures that all sections (Admin, Patient, Encounter, Assessment)
        *                 are parsed and stored in ParsedFlatFile.
        *********************************************************************************/
        [Fact]
        public void ParseFile_ShouldParseAllSectionsCorrectly()
        {
            // Arrange
            var filePath = Path.Combine(_testDataDir, "sample.dat");
            CreateSampleFlatFile(filePath);

            var parser = new FlatFileParser();

            // Act
            var result = parser.ParseFile(filePath);

            // Assert
            result.Should().NotBeNull();

            result.Admin.Fields.Should()
                .ContainKey("rec_id")
                .WhoseValue.Should().Be("2025070041");

            result.Patient.Fields.Should()
                .ContainKey("A5A")
                .WhoseValue.Should().Be("1234567897");

            result.Encounter.Fields.Should()
                .ContainKey("B2")
                .WhoseValue.Should().Be("2025-06-01");

            result.AssessmentSections.Should().ContainKey("SECTION A");
            result.AssessmentSections["SECTION A"].Should()
                .ContainKey("A4")
                .WhoseValue.Should().Be("T");

        }

        /********************************************************************************
        * FUNCTION      : ParseFile_ShouldThrowIfFileNotFound
        * DESCRIPTION   : Ensures FileNotFoundException is thrown if the file does not exist.
        *********************************************************************************/
        [Fact]
        public void ParseFile_ShouldThrowIfFileNotFound()
        {
            // Arrange
            var parser = new FlatFileParser();

            // Act & Assert
            Action act = () => parser.ParseFile("nonexistent.dat");
            act.Should().Throw<FileNotFoundException>();
        }

        #region TestDataHelpers

        /// <summary>
        /// Creates a sample flat file with all required sections for testing.
        /// </summary>
        private void CreateSampleFlatFile(string filePath)
        {
            var lines = new List<string>
            {
                "[ADMIN]",
                "rec_id=2025070041",
                "axType=01",
                "",
                "[PATIENT]",
                "A5A=1234567897",
                "A5B=ON",
                "",
                "[ENCOUNTER]",
                "B2=2025-06-01",
                "",
                "[SECTION A]",
                "A4=T",
                "A7=Y"
            };

            File.WriteAllLines(filePath, lines);
        }

        #endregion
    }
}
