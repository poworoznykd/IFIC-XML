﻿/************************************************************************************
* FILE          : FhirXmlBuilderTests.cs
* PROJECT       : IFIC-XML
* PROGRAMMER    : Your Name
* FIRST VERSION : 2025-08-01
* DESCRIPTION   : Contains unit tests for the FhirXmlBuilder class. These tests ensure 
*                 that a valid FHIR XML bundle is generated from parsed flat file data 
*                 and mapping rules.
************************************************************************************/

using System.Collections.Generic;
using System.Xml.Linq;
using Xunit;
using FluentAssertions;
using IFIC.FileIngestor.Models;
using IFIC.FileIngestor.Builders;

namespace IFIC.Tests
{
    /********************************************************************************
    * CLASS NAME   : FhirXmlBuilderTests
    * DESCRIPTION  : Contains unit tests for verifying the functionality of FhirXmlBuilder.
    *********************************************************************************/
    public class FhirXmlBuilderTests
    {
        /********************************************************************************
        * FUNCTION     : BuildBundle_ShouldCreatePatientEncounterQuestionnaireResponse
        * DESCRIPTION  : Ensures that FhirXmlBuilder produces a Bundle with Patient, 
        *                Encounter, and QuestionnaireResponse entries populated from the 
        *                given ParsedFlatFile and MappingRules.
        *********************************************************************************/
        [Fact]
        public void BuildBundle_ShouldCreatePatientEncounterQuestionnaireResponse()
        {
            // Arrange
            var parsedFlatFile = new ParsedFlatFile
            {
                Patient = new PatientSection
                {
                    Fields = new Dictionary<string, string>
                    {
                        { "A5A", "1234567897" },
                        { "A5B", "ON" }
                    }
                },
                Encounter = new EncounterSection
                {
                    Fields = new Dictionary<string, string>
                    {
                        { "B2", "2025-06-01" }
                    }
                },
                AssessmentSections = new Dictionary<string, Dictionary<string, string>>
                {
                    { "SECTION A", new Dictionary<string, string>
                        {
                            { "A4", "T" },
                            { "A7", "Y" }
                        }
                    }
                }
            };

            var mappingRules = new List<MappingRule>
            {
                new MappingRule
                {
                    Section = "Patient",
                    FlatFileKey = "A5A",
                    FhirPath = "Patient.identifier.value",
                    DataType = "string"
                },
                new MappingRule
                {
                    Section = "Patient",
                    FlatFileKey = "A5B",
                    FhirPath = "Patient.address.postalCode",
                    DataType = "string"
                },
                new MappingRule
                {
                    Section = "Encounter",
                    FlatFileKey = "B2",
                    FhirPath = "Encounter.period.start",
                    DataType = "date"
                }
            };

            var builder = new FhirXmlBuilder(mappingRules);

            // Act
            var bundleXml = builder.BuildBundle(parsedFlatFile);
            var xmlString = bundleXml.ToString();

            // Assert
            xmlString.Should().Contain("<Bundle");
            xmlString.Should().Contain("<Patient>");
            xmlString.Should().Contain("<Encounter>");
            xmlString.Should().Contain("<QuestionnaireResponse>");
            xmlString.Should().Contain("1234567897"); // Patient identifier value
            xmlString.Should().Contain("2025-06-01"); // Encounter start date
            xmlString.Should().Contain("T"); // Assessment section answer
        }

        /********************************************************************************
        * FUNCTION     : BuildBundle_ShouldIncludeFHIRNamespace
        * DESCRIPTION  : Verifies that the root Bundle element includes the correct FHIR namespace.
        *********************************************************************************/
        [Fact]
        public void BuildBundle_ShouldIncludeFHIRNamespace()
        {
            // Arrange
            var parsedFlatFile = new ParsedFlatFile();
            var mappingRules = new List<MappingRule>();
            var builder = new FhirXmlBuilder(mappingRules);

            // Act
            var bundleXml = builder.BuildBundle(parsedFlatFile);

            // Assert
            bundleXml.Name.NamespaceName.Should().Be("http://hl7.org/fhir");
        }

    }
}
